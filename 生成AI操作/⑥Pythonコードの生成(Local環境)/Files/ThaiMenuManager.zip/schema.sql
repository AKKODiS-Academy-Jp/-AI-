CREATE TABLE IF NOT EXISTS thai_menu (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    category TEXT NOT NULL,
    image TEXT,
    spiciness INTEGER CHECK(spiciness BETWEEN 1 AND 5),
    calories INTEGER
);