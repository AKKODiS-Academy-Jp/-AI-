"""ThaiMenuManager: タイ料理メニュー管理Webアプリ"""

import os
import sqlite3
from flask import Flask, render_template, request, redirect, url_for, flash
from werkzeug.utils import secure_filename

app = Flask(__name__)
app.secret_key = "supersecretkey"
app.config["UPLOAD_FOLDER"] = os.path.join("static", "uploads")
os.makedirs(app.config["UPLOAD_FOLDER"], exist_ok=True)

DATABASE = "thai_menu.db"

def get_db_connection():
    conn = sqlite3.connect(DATABASE)
    conn.row_factory = sqlite3.Row
    return conn

@app.route("/")
def index():
    conn = get_db_connection()
    menus = conn.execute("SELECT * FROM thai_menu").fetchall()
    conn.close()
    return render_template("index.html", menus=menus)

@app.route("/add", methods=["GET", "POST"])
def add_menu():
    if request.method == "POST":
        name = request.form["name"]
        category = request.form["category"]
        spiciness = int(request.form["spiciness"])
        calories = int(request.form["calories"])
        image_file = request.files["image"]

        image_path = None
        if image_file and image_file.filename:
            filename = secure_filename(image_file.filename)
            image_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            image_file.save(image_path)

        conn = get_db_connection()
        conn.execute(
            "INSERT INTO thai_menu (name, category, image, spiciness, calories) VALUES (?, ?, ?, ?, ?)",
            (name, category, image_path, spiciness, calories),
        )
        conn.commit()
        conn.close()
        flash("メニューを追加しました。")
        return redirect(url_for("index"))

    return render_template("add.html")

@app.route("/edit/<int:menu_id>", methods=["GET", "POST"])
def edit_menu(menu_id):
    conn = get_db_connection()
    menu = conn.execute("SELECT * FROM thai_menu WHERE id = ?", (menu_id,)).fetchone()

    if request.method == "POST":
        name = request.form["name"]
        category = request.form["category"]
        spiciness = int(request.form["spiciness"])
        calories = int(request.form["calories"])
        image_file = request.files["image"]

        image_path = menu["image"]
        if image_file and image_file.filename:
            filename = secure_filename(image_file.filename)
            image_path = os.path.join(app.config["UPLOAD_FOLDER"], filename)
            image_file.save(image_path)

        conn.execute(
            "UPDATE thai_menu SET name=?, category=?, image=?, spiciness=?, calories=? WHERE id=?",
            (name, category, image_path, spiciness, calories, menu_id),
        )
        conn.commit()
        conn.close()
        flash("メニューを更新しました。")
        return redirect(url_for("index"))

    conn.close()
    return render_template("edit.html", menu=menu)

@app.route("/delete/<int:menu_id>", methods=["POST"])
def delete_menu(menu_id):
    conn = get_db_connection()
    conn.execute("DELETE FROM thai_menu WHERE id=?", (menu_id,))
    conn.commit()
    conn.close()
    flash("メニューを削除しました。")
    return redirect(url_for("index"))

if __name__ == "__main__":
    app.run(debug=True)
